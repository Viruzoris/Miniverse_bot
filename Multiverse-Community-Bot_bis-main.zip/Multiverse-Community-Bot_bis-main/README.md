# Multiverse-Community-Bot
A bot designed to manage a lovely discord


run 

$node deploy-commands.js
to update command

run 

$node index.js
to deploy the bot locally

